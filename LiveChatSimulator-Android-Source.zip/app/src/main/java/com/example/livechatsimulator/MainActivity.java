package com.example.livechatsimulator;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView status;
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(22));
        root.setBackgroundColor(Color.rgb(15,17,24));
        setContentView(root);

        TextView title = new TextView(this);
        title.setText("LIVE CHAT SIMULATOR");
        title.setTextColor(Color.WHITE); title.setTextSize(23); title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(58)));

        TextView desc = new TextView(this);
        desc.setText("Simulação de live brasileira para acompanhar seu desafio no Subway Surfers sem pegar moedas.");
        desc.setTextColor(Color.LTGRAY); desc.setTextSize(15); desc.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-1, dp(80)); dlp.bottomMargin=dp(18);
        root.addView(desc, dlp);

        Button permission = button("1. Permitir sobreposição na tela");
        root.addView(permission);
        permission.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
                startActivity(i);
            } else Toast.makeText(this, "Permissão já concedida.", Toast.LENGTH_SHORT).show();
        });

        Button start = button("2. Iniciar chat flutuante");
        root.addView(start);
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Conceda a permissão de sobreposição primeiro.", Toast.LENGTH_LONG).show();
                return;
            }
            startService(new Intent(this, OverlayService.class));
            status.setText("Simulação ativa. Você pode abrir o Subway Surfers.");
        });

        Button stop = button("Parar simulação");
        root.addView(stop);
        stop.setOnClickListener(v -> { stopService(new Intent(this, OverlayService.class)); status.setText("Simulação parada."); });

        status = new TextView(this);
        status.setText("Status: aguardando início");
        status.setTextColor(Color.rgb(120,220,170)); status.setTextSize(14); status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, dp(58)); slp.topMargin=dp(12);
        root.addView(status, slp);

        TextView note = new TextView(this);
        note.setText("Dica: arraste a faixa superior do chat para mudar de posição. Toque em × para fechar. Esta versão usa eventos simulados; ela não lê automaticamente o que acontece no jogo.");
        note.setTextColor(Color.GRAY); note.setTextSize(12);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-1, -2); nlp.topMargin=dp(18);
        root.addView(note, nlp);
    }

    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54)); p.bottomMargin=dp(10);
        b.setLayoutParams(p); return b;
    }
}
