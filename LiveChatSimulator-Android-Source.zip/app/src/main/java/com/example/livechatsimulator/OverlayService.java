package com.example.livechatsimulator;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.*;

public class OverlayService extends Service {
    private WindowManager wm;
    private LinearLayout panel, header, messages;
    private WindowManager.LayoutParams params;
    private Handler handler = new Handler();
    private Random random = new Random();
    private int viewers = 0;
    private boolean running = false;
    private final Set<String> active = new HashSet<>();
    private final String[] names = {"Alexandre","Biel","GhostBR","junin.exe","Lucas","N1tro","cafecomleite","Vitin","ZeroFPS","luis.jpg","Rafael","morreuprotrem","Kira.exe","Gui","notfound","Pedro","777zin","Dudu","Henrique","semSorte123"};
    private final String[] chat = {
        "mano essa run tá muito boa","KKKKKK COMO TU DESVIOU","NÃO PEGA ESSA MOEDA","mds mn q isso","vai dar bom confia",
        "CUIDADO NA FRENTE","quanto tempo sem pegar moeda?","KKKKKKKKKK","essa run tá insana","papo reto tu vai conseguir",
        "não acredito que passou","VAI VAI VAI","entrou no modo automático KKKK","slk quase foi 😭","boa boa boa",
        "ainda sem pegar moeda??","esse desafio é impossível kkkkk","calma que dá","MANO OLHA O TREM","fé no pai"
    };
    private final String[] gifts = {"🌹 enviou uma Rosa","❤️ enviou um Coração","🎁 enviou um Presente","💎 enviou um Diamante","🦁 enviou um Leão"};

    @Override public void onCreate() {
        super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); createOverlay();
        running=true; scheduleViewer(); scheduleMessage(); scheduleGift();
    }
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String s,int size,int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setPadding(dp(7),dp(4),dp(7),dp(4)); return t;
    }
    private void createOverlay(){
        panel=new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(7),dp(5),dp(7),dp(7)); panel.setBackgroundColor(0xCC171923);
        header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(5),dp(3),dp(3),dp(3)); header.setBackgroundColor(0xFF262A38);
        TextView live=text("● AO VIVO  ",12,0xFFFF5B70); TextView count=text("👥 0",12,Color.WHITE); TextView close=text("×",20,Color.WHITE); close.setGravity(Gravity.CENTER);
        header.addView(live); header.addView(count); header.addView(new View(this),new LinearLayout.LayoutParams(0,1,1)); header.addView(close,new LinearLayout.LayoutParams(dp(30),dp(30)));
        header.setTag(count); panel.addView(header,new LinearLayout.LayoutParams(-1,dp(34)));
        ScrollView scroll=new ScrollView(this); messages=new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL); scroll.addView(messages);
        panel.addView(scroll,new LinearLayout.LayoutParams(-1,dp(210)));
        params=new WindowManager.LayoutParams(dp(275),dp(255),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.LEFT; params.x=dp(12); params.y=dp(120);
        try { wm.addView(panel,params); } catch(Exception e){stopSelf();return;}
        header.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy;
            public boolean onTouch(View v,MotionEvent ev){if(ev.getAction()==0){sx=ev.getRawX();sy=ev.getRawY();ox=params.x;oy=params.y;return true;}
                if(ev.getAction()==2){params.x=ox+(int)(ev.getRawX()-sx);params.y=oy+(int)(ev.getRawY()-sy);wm.updateViewLayout(panel,params);return true;} return true;}});
        close.setOnClickListener(v->stopSelf());
        addLine("Sistema","A live começou! desafio sem pegar moedas 👀");
    }
    private void updateCount(){
        if(header!=null){TextView c=(TextView)header.getTag(); c.setText("👥 "+viewers);}
    }
    private void addLine(String name,String msg){
        if(messages==null)return;
        TextView t=text(name+": "+msg,12,Color.WHITE); messages.addView(t);
        while(messages.getChildCount()>12)messages.removeViewAt(0);
    }
    private String pick(String[] a){return a[random.nextInt(a.length)];}
    private void scheduleViewer(){
        if(!running)return;
        handler.postDelayed(()->{
            if(!running)return;
            int change;
            if(random.nextInt(100)<54) change=1+random.nextInt(5);
            else change=-(1+random.nextInt(4));
            viewers=Math.max(0,Math.min(230,viewers+change)); updateCount(); scheduleViewer();
        }, 2500+random.nextInt(9000));
    }
    private void scheduleMessage(){
        if(!running)return;
        handler.postDelayed(()->{
            if(!running)return;
            if(viewers>0 && random.nextInt(100)<68){
                String who=pick(names); addLine(who,pick(chat));
            }
            scheduleMessage();
        }, 1800+random.nextInt(8500));
    }
    private void scheduleGift(){
        if(!running)return;
        handler.postDelayed(()->{
            if(!running)return;
            if(viewers>0 && random.nextInt(100)<18){
                String who=pick(names); String gift=pick(gifts);
                addLine("🎁 "+who,gift);
                addLine("Sistema","✨ "+who+" mandou um presente!");
            }
            scheduleGift();
        }, 18000+random.nextInt(42000));
    }
    @Override public int onStartCommand(Intent i,int f,int id){return START_NOT_STICKY;}
    @Override public void onDestroy(){running=false;handler.removeCallbacksAndMessages(null);if(panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
