LIVE CHAT SIMULATOR — PROJETO ANDROID

Nome padrão: Live Chat Simulator
Plataforma: Android
Pacote: com.example.livechatsimulator

O que esta primeira versão implementa:
- Tela inicial para conceder permissão de sobreposição.
- Janela flutuante sobre outros aplicativos.
- Cabeçalho de live e contador variável de espectadores.
- Comentários em português brasileiro.
- Presentes simulados em intervalos variáveis.
- Arrastar a janela pela faixa superior.
- Fechar o overlay pelo botão ×.

Limitações desta primeira versão:
- Não é um APK compilado. É o projeto-fonte Android.
- O ambiente usado para gerar este pacote não possui Android SDK/Gradle instalados, então não foi possível compilar e validar um APK aqui.
- O contador e os comentários são simulações locais.
- Não há leitura automática do gameplay.
- Ajustes avançados (redimensionamento, controle de velocidade, persistência de espectadores e sons) ainda não foram implementados.

Para gerar o APK, o projeto precisa ser aberto em Android Studio e compilado com Android SDK instalado.
